/**
 * Gen6 Deluxe pin assignments
 */

#include "pins_GEN6.h"
