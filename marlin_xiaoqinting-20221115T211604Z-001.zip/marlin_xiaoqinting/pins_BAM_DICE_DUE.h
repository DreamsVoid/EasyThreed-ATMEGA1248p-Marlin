/**
 * BAM&DICE Due (Arduino Mega) pin assignments
 */

#include "pins_RAMPS_13_EFB.h"

#undef TEMP_0_PIN
#undef TEMP_1_PIN
#define TEMP_0_PIN          9 // ANALOG NUMBERING
#define TEMP_1_PIN         11 // ANALOG NUMBERING
